# ZLogger

Remote persistent keylogger for Windows and Linux.

Features:
- Logs keys pressed on keyboard
- Sends reports by email.
- Starts with system startup.
- Works with Linux and Windows.
- Does not require root or admin privlages.



